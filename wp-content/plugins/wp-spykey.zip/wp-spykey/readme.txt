=== Plugin Name ===
Contributors: WP-Spykey
Donate link: http://geronikolov.com
Tags: statistics, tracking, spying, visitors
Requires at least: 3.1
Tested up to: 4.7
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin will help you to understand what your visitors like the most.

== Description ==

This plugin is meant to tell you the most valuable information about your site visitors.

It also provides the ability to check where on map was your visitor when he hit your website.

This plugin is great for preventing hack attacks with knowing when and from where your visitors are checking your site.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)
